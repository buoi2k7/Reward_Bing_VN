# Bing Rewards Auto

Chrome/Edge extension for Microsoft Rewards search automation.

## Features

- PC search automation with configurable count and speed.
- Optional mobile search with mobile user-agent rules.
- Direct search counts without Rewards Level presets.
- Linear run flow without wave pauses or long cooldown blocks.
- Optional result clicking and short read simulation.
- Points check and daily progress tracking.
- Activity/counter scan before search, with account diagnostics for restriction warning signs.
- Reset page/tabs and safe browsing-data cleanup.

This extension no longer automates Daily Set, punch cards, or other Rewards tasks.
